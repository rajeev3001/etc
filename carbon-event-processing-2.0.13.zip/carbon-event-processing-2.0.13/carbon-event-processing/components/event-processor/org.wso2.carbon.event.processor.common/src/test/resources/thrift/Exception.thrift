namespace java org.wso2.carbon.event.processor.storm.common.manager.service.exception


exception NotStormManagerException {
    1: required string message
}

exception EndpointNotFoundException {
    1: required string message
}
